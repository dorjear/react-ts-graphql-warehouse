## Installing the dependencies and running the app

- Simply run the following command to install the dependencies:
`npm install`

- And start the server with:
`npm run start`

Additional information are found [here](https://www.scalablepath.com/full-stack/graphql-and-postgraphile-integration-full-stack-tutorial-part-2).