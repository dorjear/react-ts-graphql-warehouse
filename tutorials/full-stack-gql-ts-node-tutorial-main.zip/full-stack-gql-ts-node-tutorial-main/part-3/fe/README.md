## Installing the dependencies and running the app

- Simply run the following command to install the dependencies:
`npm install`

- And start the server with:
`npm run start`

Please make sure that you have the API backend running to start the frontend.